drc version:    1.2c updated
lvs version:    1.2c updated
dummy verison:  1.2b
perc verion:    1.1c
ant version:    1.2b
bump version:   1.2b

update lvs and drc
