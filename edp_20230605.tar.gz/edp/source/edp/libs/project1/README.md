# The owener is project1's owner

the libs contains all libs information

the tech contains all tech information

