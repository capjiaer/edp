3 dirs here
	scripts >
		the main scripts here for cmds
	util >
		the utilization scripts, such as pre_scripts and post scripts if required
	func > 
		functions for the special database sort if required
