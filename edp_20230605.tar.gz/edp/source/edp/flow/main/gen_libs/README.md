A class required for below info generation:
    
